# Basic Web Calculator

A simple calculator built with HTML, JavaScript and CSS.

## How to Use
Open `calculator.html` in your browser and perform basic addition.
