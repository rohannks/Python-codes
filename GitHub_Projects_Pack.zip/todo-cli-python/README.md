# To-Do List CLI App

A simple terminal-based To-Do list application written in Python.

## Features
- Add new tasks
- Remove tasks
- Display tasks

## How to Run
```bash
python todo.py
```
