tasks = []

while True:
    print("\nTo-Do List:")
    for i, task in enumerate(tasks, 1):
        print(f"{i}. {task}")
    print("\nOptions: [1] Add Task  [2] Remove Task  [3] Exit")
    choice = input("Enter choice: ")

    if choice == "1":
        task = input("Enter new task: ")
        tasks.append(task)
    elif choice == "2":
        num = int(input("Enter task number to remove: "))
        if 1 <= num <= len(tasks):
            tasks.pop(num - 1)
    elif choice == "3":
        break
    else:
        print("Invalid choice.")
