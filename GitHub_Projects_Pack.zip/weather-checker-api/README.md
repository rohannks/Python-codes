# Weather Checker using API

Python script to fetch current weather using OpenWeatherMap API.

## How to Run
1. Get your API key from https://openweathermap.org
2. Replace `"your_api_key_here"` with your API key
3. Run using:

```bash
python weather_check.py
```
