# Password Generator

A Python script that generates strong random passwords using letters, digits, and special characters.

## How to Run
```bash
python password_generator.py
```
