# Personal Portfolio

A clean and minimal personal portfolio website built with HTML and CSS.

## Features
- Personal intro
- Social links

## How to View
Open `index.html` in your browser.
